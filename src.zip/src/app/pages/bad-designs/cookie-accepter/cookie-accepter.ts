import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cookie-accepter',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './cookie-accepter.html',
  styleUrl: './cookie-accepter.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CookieAccepter {}
